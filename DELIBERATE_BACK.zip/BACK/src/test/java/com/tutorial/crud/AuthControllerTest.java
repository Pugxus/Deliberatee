package com.tutorial.crud;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Disabled
public class AuthControllerTest {

	
	@Test
	public final void givenJsonWithInvalidList_whenDeserializing_thenThrowException() throws JsonParseException, IOException {
	    String json = "{\"name\":\"Netherlands\",\"cities\":{\"Amsterdam\", \"Tamassint\"}}";
	    ObjectMapper mapper = new ObjectMapper();

	    Exception exception = assertThrows(JsonMappingException.class, () -> mapper.reader()
	    
	      .readValue(json));

	    assertTrue(exception.getMessage()
	      .contains("Cannot deserialize value of type `java.util.ArrayList<java.lang.String>`"));
	}
}
