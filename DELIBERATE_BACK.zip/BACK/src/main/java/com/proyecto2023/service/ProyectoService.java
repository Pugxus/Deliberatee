package com.proyecto2023.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.proyecto2023.crud.entity.Proyecto;
import com.proyecto2023.repository.ProyectoRepository;

@Service
@Transactional
public class ProyectoService {

    @Autowired
    ProyectoRepository proyectoRepository;

    public List<Proyecto> list() {
        return proyectoRepository.findAll();

    }
    
    public Optional<Proyecto> getOne(int id) {
        return proyectoRepository.findById(id);
    }

    public List<Proyecto> findByUsuarioProyecto(String usuario) {
        return proyectoRepository.findByUsuarioProyecto(usuario);
    }

    public Optional<Proyecto> getByTitulo(String titulo) {
        return proyectoRepository.findByTitulo(titulo);
    }

    public void save(Proyecto proyecto) {
        proyectoRepository.save(proyecto);
    }

    public void delete(int id) {
        proyectoRepository.deleteById(id);
    }

    public boolean existsById(int id) {
        return proyectoRepository.existsById(id);
    }

    public boolean existsByTitulo(String titulo) {
        return proyectoRepository.existsByTitulo(titulo);
    }
}
