package com.proyecto2023.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.proyecto2023.crud.dto.HorarioDto;
import com.proyecto2023.crud.entity.Asignatura;
import com.proyecto2023.crud.entity.Horario;
import com.proyecto2023.repository.AsignaturaRepository;
import com.proyecto2023.repository.HorarioRepository;

import net.bytebuddy.dynamic.DynamicType.Builder.FieldDefinition.Optional;


@Service
@Transactional
public class HorarioService {
	@Autowired
    HorarioRepository horarioRepository;
	
	public List<Horario> list() {
        return horarioRepository.findAll();
    }
	
	
}
