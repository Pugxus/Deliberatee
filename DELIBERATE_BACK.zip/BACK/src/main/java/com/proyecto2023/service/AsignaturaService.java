package com.proyecto2023.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.proyecto2023.crud.entity.Asignatura;
import com.proyecto2023.repository.AsignaturaRepository;


@Service
@Transactional
public class AsignaturaService {

	@Autowired
    AsignaturaRepository asignaturaRepository;

    public List<Asignatura> list() {
        return asignaturaRepository.findAll();

    }
    
}
