package com.proyecto2023.util;

import com.proyecto2023.security.entity.Rol;
import com.proyecto2023.security.enums.RolNombre;
import com.proyecto2023.security.service.RolService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;


/**
 * MUY IMPORTANTE: ESTA CLASE SÓLO SE EJECUTARÁ UNA VEZ PARA CREAR LOS ROLES.
 * UNA VEZ CREADOS SE DEBERÁ ELIMINAR O BIEN COMENTAR EL CÓDIGO
 *
 */

@Component
public class CreateRoles implements CommandLineRunner {

    @Autowired
    RolService rolService;

    @Override
    public void run(String... args) throws Exception {
      /*/ Rol rolEstudiante = new Rol(RolNombre.ROLE_ESTUDIANTE);
        Rol rolDocente = new Rol(RolNombre.ROLE_DOCENTE);
        rolService.save(rolDocente);
        rolService.save(rolEstudiante);/*/
         
    }
}
