package com.proyecto2023.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.proyecto2023.crud.entity.Proyecto;

@Repository
public interface ProyectoRepository extends JpaRepository<Proyecto, Integer> {

    Optional<Proyecto> findByTitulo(String titulo);

    boolean existsByTitulo(String titulo);

    @Query(value = "SELECT * FROM proyecto WHERE cod_docente = :usuario OR cod_estudiante = :usuario",
            nativeQuery = true)
    List<Proyecto> findByUsuarioProyecto(@Param("usuario") String usuario);
    
    
}
