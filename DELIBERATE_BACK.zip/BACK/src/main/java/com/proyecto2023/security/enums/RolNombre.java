package com.proyecto2023.security.enums;

public enum RolNombre {
    ROLE_ADMIN, ROLE_DOCENTE, ROLE_ESTUDIANTE
}
