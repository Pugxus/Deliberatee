package com.proyecto2023.security.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.proyecto2023.crud.entity.Proyecto;
import com.proyecto2023.security.entity.Usuario;

import java.util.List;
import java.util.Optional;

@Repository
public interface UsuarioRepository extends JpaRepository<Usuario, Integer> {
    Optional<Usuario> findByNombreUsuario(String nombreUsuario);
    Optional<Usuario> findByTokenPassword(String tokenPassword);
    Optional<Usuario> findByNombreUsuarioOrEmail(String nombreUsuario, String email);
    Optional<Usuario> findByNombre(String nombre);
    boolean existsByNombreUsuario(String nombreUsuario);
    boolean existsByNombre(String nombre);
    boolean existsByEmail(String email);
    
    
    
    @Query(value = "SELECT * FROM usuario u JOIN usuario_rol ur ON u.id = ur.usuario_id JOIN rol r ON ur.rol_id = r.id WHERE r.rol_nombre = 'ROLE_DOCENTE'",
            nativeQuery = true)
    List<Usuario> findByDocente();
    
    @Query(value = "SELECT * FROM usuario u JOIN usuario_rol ur ON u.id = ur.usuario_id JOIN rol r ON ur.rol_id = r.id WHERE r.rol_nombre = 'ROLE_ESTUDIANTE'",
            nativeQuery = true)
	List<Usuario> findByEstudiante();
 
  
    @Query(value = "INSERT INTO usuario_rol (usuario_id, rol_id) VALUES (:usuarioId, :rolId)", nativeQuery = true)
    void asignarRol(@Param("usuarioId") int usuarioId, @Param("rolId") int rolId);

    
    @Query(value = "DELETE FROM usuario_rol WHERE usuario_id = :usuarioId AND rol_id = :rolId", nativeQuery = true)
    void desasignarRol(@Param("usuarioId") int usuarioId, @Param("rolId") int rolId);

    @Modifying
    @Query(value = "UPDATE usuario_rol SET rol_id = :nuevoRolId WHERE usuario_id = :usuarioId", nativeQuery = true)
    void actualizarRol(@Param("usuarioId") int usuarioId, @Param("nuevoRolId") int nuevoRolId);

    
}
