package com.proyecto2023.controller;

import java.util.List;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.proyecto2023.crud.dto.Mensaje;
import com.proyecto2023.crud.dto.ProyectoDto;
import com.proyecto2023.crud.entity.Proyecto;
import com.proyecto2023.service.ProyectoService;

@RestController
@RequestMapping("/proyecto")
@CrossOrigin(origins = "*")
public class ProyectoController {

    @Autowired
    ProyectoService proyectoService;

    @GetMapping("/getProyecto/{usuario}")
    public List<Proyecto> findByUsuarioProyecto(@PathVariable("usuario") String usuario) {
        return proyectoService.findByUsuarioProyecto(usuario);
    }

    @GetMapping("/lista")
    public ResponseEntity<List<Proyecto>> list() {
        List<Proyecto> list = proyectoService.list();
        return new ResponseEntity(list, HttpStatus.OK);
    }

    @GetMapping("/detail/{id}")
    public ResponseEntity<Proyecto> getById(@PathVariable("id") int id) {
        if (!proyectoService.existsById(id)) {
            return new ResponseEntity(new Mensaje("no existe"), HttpStatus.NOT_FOUND);
        }
        Proyecto proyecto = proyectoService.getOne(id).get();
        return new ResponseEntity(proyecto, HttpStatus.OK);
    }

    @GetMapping("/detailname/{titulo}")
    public ResponseEntity<Proyecto> getByTitulo(@PathVariable("titulo") String titulo) {
        if (!proyectoService.existsByTitulo(titulo)) {
            return new ResponseEntity(new Mensaje("no existe"), HttpStatus.NOT_FOUND);
        }
        Proyecto proyecto = proyectoService.getByTitulo(titulo).get();
        return new ResponseEntity(proyecto, HttpStatus.OK);
    }

    @PreAuthorize("hasAnyRole('ADMIN', 'ESTUDIANTE')")
    @PostMapping("/create")
    public ResponseEntity<?> create(@RequestBody ProyectoDto proyectoDto) {
        if (StringUtils.isBlank(proyectoDto.getTitulo())) {
            return new ResponseEntity(new Mensaje("El titulo es obligatorio"), HttpStatus.BAD_REQUEST);
        }
        if (proyectoDto.getNota() < 0) {
            return new ResponseEntity(new Mensaje("La nota debe ser mayor que 0"), HttpStatus.BAD_REQUEST);
        }
        if (proyectoService.existsByTitulo(proyectoDto.getTitulo())) {
            return new ResponseEntity(new Mensaje("El titulo ya existe"), HttpStatus.BAD_REQUEST);
        }
        Proyecto proyecto = new Proyecto(proyectoDto.getTitulo(), proyectoDto.getDescripcion(), proyectoDto.getAsignatura(),proyectoDto.getSalon(),proyectoDto.getHorario(), proyectoDto.getCod_docente(), proyectoDto.getCod_estudiante(), proyectoDto.getComentario(),proyectoDto.getNota());
        proyectoService.save(proyecto);
        return new ResponseEntity(new Mensaje("proyecto creado"), HttpStatus.OK);
    }

    // @PreAuthorize("hasRole('ADMIN')")
    @PreAuthorize("hasAnyRole('ADMIN', 'DOCENTE', 'ESTUDIANTE')")

    @PutMapping("/update/{id}")
    public ResponseEntity<?> update(@PathVariable("id") int id, @RequestBody ProyectoDto proyectoDto) {
        if (!proyectoService.existsById(id)) {
            return new ResponseEntity(new Mensaje("no existe"), HttpStatus.NOT_FOUND);
        }
        /*/
        if (proyectoService.existsByTitulo(proyectoDto.getTitulo()) && proyectoService.getByTitulo(proyectoDto.getTitulo()).get().getId() != id) {
            return new ResponseEntity(new Mensaje("El titulo ya existe"), HttpStatus.BAD_REQUEST);
        }/*/
        if (StringUtils.isBlank(proyectoDto.getTitulo())) {
            return new ResponseEntity(new Mensaje("El titulo es obligatorio"), HttpStatus.BAD_REQUEST);
        }
        if (proyectoDto.getNota() < 0) {
            return new ResponseEntity(new Mensaje("La nota debe ser mayor que 0"), HttpStatus.BAD_REQUEST);
        }

        Proyecto proyecto = proyectoService.getOne(id).get();
        proyecto.setTitulo(proyectoDto.getTitulo());
        proyecto.setDescripcion(proyectoDto.getDescripcion());
        proyecto.setAsignatura(proyectoDto.getAsignatura());
        proyecto.setSalon(proyectoDto.getSalon());
        proyecto.setHorario(proyectoDto.getHorario());
        proyecto.setCod_docente(proyectoDto.getCod_docente());
        proyecto.setCod_estudiante(proyectoDto.getCod_estudiante());
        proyecto.setComentario(proyectoDto.getComentario());
        proyecto.setNota(proyectoDto.getNota());
        proyectoService.save(proyecto);
        return new ResponseEntity(new Mensaje("Proyecto actualizado"), HttpStatus.OK);
    }

    
    @PreAuthorize("hasRole('DOCENTE')")
    @PutMapping("/updateNota/{id}")
    public ResponseEntity<?> updateNota(@PathVariable("id") int id, @RequestBody ProyectoDto proyectoDto) {
        if (!proyectoService.existsById(id)) {
            return new ResponseEntity(new Mensaje("no existe"), HttpStatus.NOT_FOUND);
        }  
        if (proyectoDto.getNota() < 0 || proyectoDto.getNota()>50) {
            return new ResponseEntity(new Mensaje("La nota debe ser menor o igual a 50"), HttpStatus.BAD_REQUEST);
        }

        Proyecto proyecto = proyectoService.getOne(id).get();
        proyecto.setNota(proyectoDto.getNota());
        proyecto.setComentario(proyectoDto.getComentario());
        proyectoService.save(proyecto);
        return new ResponseEntity(new Mensaje("Nota actualizado"), HttpStatus.OK);
    }
    
    
    
    @PreAuthorize("hasRole('ADMIN')")
    @DeleteMapping("/delete/{id}")
    public ResponseEntity<?> delete(@PathVariable("id") int id) {
        if (!proyectoService.existsById(id)) {
            return new ResponseEntity(new Mensaje("no existe"), HttpStatus.NOT_FOUND);
        }
        proyectoService.delete(id);
        return new ResponseEntity(new Mensaje("Proyecto eliminado"), HttpStatus.OK);
    }
    
    

}
