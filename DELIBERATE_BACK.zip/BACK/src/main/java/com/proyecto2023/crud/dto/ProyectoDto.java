package com.proyecto2023.crud.dto;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;

public class ProyectoDto {

    @NotBlank
    private String titulo;
    @NotBlank
    private String descripcion;
    @NotBlank
    private String asignatura;
    @NotBlank
    private String salon;
    @NotBlank
    private String horario;
    private String cod_docente;
    @NotBlank
    private String cod_estudiante;
    @NotBlank
    private String comentario;
    @Min(0)
    private int nota;

    public ProyectoDto() {
    }

    public ProyectoDto(@NotBlank String titulo, @NotBlank String descripcion, @NotBlank String asignatura,@NotBlank String horario,@NotBlank String salon, String cod_docente, @NotBlank String cod_estudiante,@NotBlank String comentario, @Min(0) int nota) {
        this.titulo = titulo;
        this.descripcion = descripcion;
        this.asignatura = asignatura;
        this.salon=salon;
        this.horario=horario;
        this.cod_docente = cod_docente;
        this.cod_estudiante = cod_estudiante;
        this.comentario = comentario;
        this.nota = nota;
    }

    public String getCod_docente() {
        return cod_docente;
    }

    public void setCod_docente(String cod_docente) {
        this.cod_docente = cod_docente;
    }

    public String getCod_estudiante() {
        return cod_estudiante;
    }

    public String getSalon() {
		return salon;
	}

	public void setSalon(String salon) {
		this.salon = salon;
	}

	

	public String getHorario() {
		return horario;
	}

	public void setHorario(String horario) {
		this.horario = horario;
	}

	public void setCod_estudiante(String cod_estudiante) {
        this.cod_estudiante = cod_estudiante;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getAsignatura() {
        return asignatura;
    }

    public void setAsignatura(String asignatura) {
        this.asignatura = asignatura;
    }

    public int getNota() {
        return nota;
    }

    public void setNota(int nota) {
        this.nota = nota;
    }

	public String getComentario() {
		return comentario;
	}

	public void setComentario(String comentario) {
		this.comentario = comentario;
	}

}
