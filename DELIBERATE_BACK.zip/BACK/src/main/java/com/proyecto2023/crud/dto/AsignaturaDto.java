package com.proyecto2023.crud.dto;

import javax.validation.constraints.NotBlank;

public class AsignaturaDto {
	  @NotBlank	 
	  private String nombreAsignatura;


	    public AsignaturaDto() {
	    }

	    public AsignaturaDto(@NotBlank String nombreAsignatura) {
	        this.nombreAsignatura = nombreAsignatura;
	    }

		public String getNombreAsignatura() {
			return nombreAsignatura;
		}

		public void setNombreAsignatura(String nombreAsignatura) {
			this.nombreAsignatura = nombreAsignatura;
		}

}
