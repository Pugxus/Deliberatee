package com.proyecto2023.crud.dto;

import javax.validation.constraints.NotBlank;

public class SalonDto {

	 @NotBlank	 
	  private String salon;
	 
	    public SalonDto() {
	    }
	    
	    public SalonDto(@NotBlank String salon) {
	        this.salon = salon;
	        
	    }

		public String getSalon() {
			return salon;
		}

		public void setSalon(String salon) {
			this.salon = salon;
		}


}
