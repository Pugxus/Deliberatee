package com.proyecto2023.crud.dto;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;

public class HorarioDto {

	  @NotBlank	 
	  private String horario;
	 
	    public HorarioDto() {
	    }
	    
	    public HorarioDto(@NotBlank String horario) {
	        this.horario = horario;
	        
	    }

		public String getHorario() {
			return horario;
		}

		public void setHorario(String horario) {
			this.horario = horario;
		}

		

		
}
