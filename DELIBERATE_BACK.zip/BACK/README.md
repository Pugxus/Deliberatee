# tutorial_jwt_BACK
jwt security api REST 

basic CRUD with JWT authentication based on roles
